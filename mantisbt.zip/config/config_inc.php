<?php
$g_hostname               = 'localhost';
$g_db_type                = 'mysqli';
$g_database_name          = 'bugtracker';
$g_db_username            = 'root';
$g_db_password            = '';

$g_default_timezone       = 'America/El_Salvador';

$g_crypto_master_salt     = '/E46SkQS28lLyyhEBAXm0r2+IyMT6sjDnoVlU9GO4is=';

$g_path                   = 'http://localhost/mantisbt/';
